# c2express01

Test simple routes in Express eg GET, POST
use GitHub Actions to create image and push to DockerHub
